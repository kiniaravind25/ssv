# Billing_Sytem
 An electrical billing object oriented terminal based java applicaon that facilies a
billing person to bill a user on the rate of electricity used by him. Registraon of a new
user, edit details of registered user and also delete user is entertained.
