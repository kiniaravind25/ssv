#!/usr/bin/python

import smtplib

sender = 'devadigarakshith17@gmail.com'
receivers = '4nm19cs150@nmamit.in'
password ='hzqcwapnjgyggexc'
subject='hwgfhewfhwf'
body='wdywefdyewgd'
message = f'Subject:{subject}\n\n{body}'

try:
    print(1)
    smtpObj = smtplib.SMTP('smtp.gmail.com',587)
    print(2)
    smtpObj.ehlo()
    smtpObj.starttls()
    smtpObj.ehlo()
    print(3)
    smtpObj.login(sender,password)
    print(4)
    smtpObj.sendmail(sender, receivers, message)         
    print(5)
    print("Successfully sent email")
except smtplib.SMTPException as e:
    
    print("Error: unable to send email",e)