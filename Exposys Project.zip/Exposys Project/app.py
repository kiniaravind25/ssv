from flask import Flask, render_template,request,flash
import os
from werkzeug.utils import secure_filename
import pandas as pd
import smtplib
import re


regex = '^[a-z0-9]+[\._]?[ a-z0-9]+[@]\w+[. ]\w{2,3}$'
def check(email):
    if(re.search(regex,email)):
        return 1
    else:
        return 0

app = Flask("__name__")
app.secret_key = "abc"  
@app.route("/",methods= ['POST','GET'])
def index():
    if request.method=='POST':

        name=request.form['name']
        from_email=request.form['from']
        password=request.form['pass']
        subject=request.form['subject']
        body=request.form['msg']
        profile = request.files['csvFile']
        profile.save(os.path.join('static/files',secure_filename('email.csv')))
        df = pd.read_csv('static/files/email.csv')
        emails=df['Email'].to_numpy()
        sender = from_email
        receivers = emails.tolist()
        message = f'Subject:{subject}\n\n{body}'
        print(receivers)
        for mail in receivers:
            if(check(mail)):
                continue
            else:
                print(mail,'is invalid email address')
                receivers.remove(mail)

        try:
            print(1)
            smtpObj = smtplib.SMTP('smtp.gmail.com',587)
            print(2)
            smtpObj.ehlo()
            smtpObj.starttls()
            smtpObj.ehlo()
            print(3)
            smtpObj.login(sender,password)
            print(4)
            smtpObj.sendmail(sender, receivers, message)         
            print(5)
            print("Successfully sent email",'success')
            return render_template('index.html')
        except smtplib.SMTPException as e:
            
            print("Error: unable to send email",e)
            flash('Unable to send mail')
        return render_template('index.html')
    else:
        return render_template('index.html')

if __name__ == '__main__':
    app.run(debug= True)